
package cp120.assignments.geo_shape;

import java.awt.Graphics2D;

/**
 *
 * @author dixya
 */
public class GeoOval extends GeoRectangle{
    @Override
    public void draw( Graphics2D gtx ){
        System.out.println("Drawing oval: origin=("+origin.getXco()+","+origin.getYco()+"),color="+"#"+Integer.toHexString(color.getRGB()).substring(2)+",width="+w+",height="+h);

}
}
